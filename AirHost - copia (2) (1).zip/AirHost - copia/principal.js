
document.addEventListener("DOMContentLoaded", function () {
    // Seleccionamos todos los elementos con la clase 'animado'
    const elementosAnimados = document.querySelectorAll('.animado');

    // Función que chequea la posición de scroll para cada elemento
    function mostrarElementos() {
        elementosAnimados.forEach((elemento) => {
            const position = elemento.getBoundingClientRect().top;
            const alturaPantalla = window.innerHeight / 1.5;

            // Si el elemento entra en vista, añadimos la clase 'visible'
            if (position < alturaPantalla) {
                elemento.classList.add('visible');
                elemento.classList.remove('oculto');
            }
        });
    }

    // Escuchamos el evento scroll para ejecutar la función
    window.addEventListener('scroll', mostrarElementos);
});


document.addEventListener("DOMContentLoaded", function () {
    // Seleccionamos todos los elementos con la clase 'animado-img2'
    const elementosAnimados = document.querySelectorAll('.animado-img2');
 
    // Función que chequea la posición del scroll para cada elemento
    function mostrarElementos() {
        elementosAnimados.forEach((elemento) => {
            const position = elemento.getBoundingClientRect().top;
            const alturaPantalla = window.innerHeight / 1.3;
 
            // Si el elemento entra en vista, añadimos la clase 'visible'
            if (position < alturaPantalla) {
                elemento.classList.add('visible');
                elemento.classList.remove('oculto');
            }
        });
    }
 
    // Escuchamos el evento scroll para ejecutar la función
    window.addEventListener('scroll', mostrarElementos);
 });
 

 const commentForm = document.getElementById('commentForm');
const commentsContainer = document.getElementById('commentsContainer');


function displayComments() {
    commentsContainer.innerHTML = ''; 

    let comments = JSON.parse(localStorage.getItem('comments')) || [];

  
    comments.forEach(comment => {
        const commentElement = document.createElement('div');
        commentElement.classList.add('comment');

        
        commentElement.innerHTML = `
            <div class="user-info">
                <div class="user-avatar">${comment.name.charAt(0).toUpperCase()}</div>
                <div class="user-details">
                    <h4>${comment.name}</h4>
                    <p>${new Date(comment.date).toLocaleDateString()} ${new Date(comment.date).toLocaleTimeString()}</p>
                </div>
            </div>
            <div class="comment-text">${comment.text}</div>
        `;

        
        commentsContainer.appendChild(commentElement);
    });
}


commentForm.addEventListener('submit', function(e) {
    e.preventDefault(); 

    const name = document.getElementById('commentName').value;
    const text = document.getElementById('commentText').value;

   
    const newComment = {
        name: name,
        text: text,
        date: new Date()
    };

    let comments = JSON.parse(localStorage.getItem('comments')) || [];
    comments.push(newComment);

    localStorage.setItem('comments', JSON.stringify(comments));

  
    commentForm.reset();

   
    displayComments();
});

document.addEventListener('DOMContentLoaded', displayComments);
