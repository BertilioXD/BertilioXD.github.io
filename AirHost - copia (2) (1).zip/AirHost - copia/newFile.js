document.addEventListener("DOMContentLoaded", function () {
   // Seleccionamos el elemento que se va a animar
   const animado = document.querySelector('.animado');

   // Función que chequea la posición de scroll
   function mostrarElemento() {
      const position = animado.getBoundingClientRect().top;
      const alturaPantalla = window.innerHeight / 1.5;

      // Si el elemento entra en vista, añadimos la clase 'visible'
      if (position < alturaPantalla) {
         animado.classList.add('visible');
         animado.classList.remove('oculto');
      }
   }
});
